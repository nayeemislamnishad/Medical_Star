# ExamVibe
This is a self Exam taking website.Where a student will compete with ownslelf 
