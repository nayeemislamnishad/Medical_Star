const gucco1="bdadcdabcccbaaaabcababaaadaabccacacddabadcdaddabbcdc";
const gucco2="accabaaaadaccabdaabdbcababcadcdbaba";
const gucco3="cabaadbadbaccbdaadbbbcabddaca";
const gucco4="adadabaaabbbcabbacdacadbadbdca";
const gucco5="abdaaccbabccdbaaabbbdbdcccccbb";
const gucco6="cbcdbcbaacabbadcdbddccbaababaccbdbbbabca";
